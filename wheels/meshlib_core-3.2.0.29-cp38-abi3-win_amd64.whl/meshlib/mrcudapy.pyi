from __future__ import annotations
import meshlib.mrmeshpy
import typing
__all__: list[str] = ['ComputePointsToDistanceVolume', 'ComputeToolDistance', 'ConstComputePointsToDistanceVolume', 'ConstComputeToolDistance', 'ConstDeviceInfo', 'ConstFastWindingNumber', 'ConstPointsProjector', 'ConstPointsToMeshProjector', 'DeviceInfo', 'FastWindingNumber', 'PointsProjector', 'PointsToMeshProjector', 'computeDistanceMap', 'computeDistanceMapHeapBytes', 'computeSkyViewFactor', 'distanceMapFromContours', 'distanceMapFromContoursHeapBytes', 'double_output', 'findProjectionOnPoints', 'findProjectionOnPointsHeapBytes', 'findSkyRays', 'float_output', 'getCudaAvailableMemory', 'getCudaSafeMemoryLimit', 'getDeviceInfo', 'int_output', 'isCudaAvailable', 'loadMRCudaDll', 'maxBufferSize', 'maxBufferSizeAlignedByBlock', 'negatePicture', 'pointsToDistanceVolume', 'pointsToDistanceVolumeByParts', 'pointsToDistanceVolumeMemory']
class ConstComputePointsToDistanceVolume(meshlib.mrmeshpy.ConstIComputePointsToDistanceVolumeByParts):
    """
    Generated from:  MR::Cuda::ComputePointsToDistanceVolume
    
    CUDA implementation of IComputePointsToDistanceVolumeByParts
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    def __init__(self, *args, **kwargs):
        """
        __init__(*args, **kwargs)
        Overloaded function.
        
        1. __init__(self: meshlib.mrcudapy.ConstComputePointsToDistanceVolume) -> None
        
        2. __init__(self: meshlib.mrcudapy.ConstComputePointsToDistanceVolume, arg0: meshlib.mrcudapy.ConstComputePointsToDistanceVolume) -> None
        
        Implicit copy constructor.
        
        3. __init__(self: meshlib.mrcudapy.ConstComputePointsToDistanceVolume, : meshlib.mrcudapy.ConstComputePointsToDistanceVolume) -> None
        """
    def canCompute(self, cloud: meshlib.mrmeshpy.ConstPointCloud, params: meshlib.mrmeshpy.ConstPointsToDistanceVolumeParams) -> bool:
        """
        see methods' descriptions in the MR::IComputePointsToDistanceVolume interfaces
        both compute() and computeByParts() upload the same data and process the grid in chunks
        sized to the free GPU memory, so this answers for either of them
        """
    def compute(self, cloud: meshlib.mrmeshpy.ConstPointCloud, params: meshlib.mrmeshpy.ConstPointsToDistanceVolumeParams) -> meshlib.mrmeshpy.SimpleVolumeMinMax:
        ...
    def computeByParts(self, cloud: meshlib.mrmeshpy.ConstPointCloud, params: meshlib.mrmeshpy.ConstPointsToDistanceVolumeParams, addPart: meshlib.mrmeshpy.Const_func_tl_expected_void_std_string_from_VoxelsVolumeMinMax_Vector_float_Id_VoxelTag_int, layerOverlap: int) -> None:
        ...
class ComputePointsToDistanceVolume(ConstComputePointsToDistanceVolume, meshlib.mrmeshpy.IComputePointsToDistanceVolumeByParts):
    """
    Generated from:  MR::Cuda::ComputePointsToDistanceVolume
    
    CUDA implementation of IComputePointsToDistanceVolumeByParts
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    @staticmethod
    @typing.overload
    def __init__(*args, **kwargs) -> None:
        ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: ConstComputePointsToDistanceVolume) -> None:
        """
        Implicit copy constructor.
        """
    def assign(self, other: ConstComputePointsToDistanceVolume) -> ComputePointsToDistanceVolume:
        ...
class ConstComputeToolDistance(meshlib.mrmeshpy.ConstIComputeToolDistance):
    """
    Generated from:  MR::Cuda::ComputeToolDistance
    
    CUDA implementation of tool distance computation
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    def __init__(self, *args, **kwargs):
        """
        __init__(self: meshlib.mrcudapy.ConstComputeToolDistance) -> None
        """
    def computeToolDistance(self, output: meshlib.mrmeshpy.VoxelScalars, dims: meshlib.mrmeshpy.ConstVector3i, voxelSize: float, origin: meshlib.mrmeshpy.ConstVector3f, padding: float) -> None:
        ...
class ComputeToolDistance(ConstComputeToolDistance, meshlib.mrmeshpy.IComputeToolDistance):
    """
    Generated from:  MR::Cuda::ComputeToolDistance
    
    CUDA implementation of tool distance computation
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    def __init__(self) -> None:
        ...
    @typing.overload
    def prepare(self, dims: meshlib.mrmeshpy.ConstVector3i, toolpath: meshlib.mrmeshpy.ConstPolyline3, toolSpec: meshlib.mrmeshpy.ConstEndMillTool) -> meshlib.mrmeshpy.Vector3i:
        ...
    @typing.overload
    def prepare(self, dims: meshlib.mrmeshpy.ConstVector3i, toolpath: meshlib.mrmeshpy.ConstPolyline3, toolProfile: meshlib.mrmeshpy.ConstPolyline2) -> meshlib.mrmeshpy.Vector3i:
        ...
class ConstDeviceInfo:
    """
    Generated from:  MR::Cuda::DeviceInfo
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    _offsetof_computeMajor: typing.ClassVar[int] = 8
    _offsetof_computeMinor: typing.ClassVar[int] = 12
    _offsetof_driverVersion: typing.ClassVar[int] = 0
    _offsetof_name: typing.ClassVar[int] = 24
    _offsetof_runtimeVersion: typing.ClassVar[int] = 4
    _offsetof_totalGlobalMem: typing.ClassVar[int] = 16
    def __init__(self, *args, **kwargs):
        """
        __init__(*args, **kwargs)
        Overloaded function.
        
        1. __init__(self: meshlib.mrcudapy.ConstDeviceInfo) -> None
        
        2. __init__(self: meshlib.mrcudapy.ConstDeviceInfo, arg0: meshlib.mrcudapy.ConstDeviceInfo) -> None
        
        Implicit copy constructor.
        
        3. __init__(self: meshlib.mrcudapy.ConstDeviceInfo, driverVersion: int, runtimeVersion: int, computeMajor: int, computeMinor: int, totalGlobalMem: int, name: str) -> None
        
        Implicit aggregate constructor.
        
        4. __init__(self: meshlib.mrcudapy.ConstDeviceInfo, : meshlib.mrcudapy.ConstDeviceInfo) -> None
        """
    def fitForComputations(self) -> bool:
        """
        returns true if all versions pass the checks
        """
    @property
    def computeMajor(self) -> int:
        """
        compute capability major version
        """
    @property
    def computeMinor(self) -> int:
        """
        compute capability minor version
        """
    @property
    def driverVersion(self) -> int:
        """
        maximum CUDA version supported by the driver
        """
    @property
    def name(self) -> str:
        """
        name of the device
        """
    @property
    def runtimeVersion(self) -> int:
        """
        application's CUDA version
        """
    @property
    def totalGlobalMem(self) -> int:
        """
        global memory on device in bytes (not all is available for our process)
        """
class DeviceInfo(ConstDeviceInfo):
    """
    Generated from:  MR::Cuda::DeviceInfo
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    @staticmethod
    @typing.overload
    def __init__(*args, **kwargs) -> None:
        ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: ConstDeviceInfo) -> None:
        """
        Implicit copy constructor.
        """
    @typing.overload
    def __init__(self, driverVersion: int, runtimeVersion: int, computeMajor: int, computeMinor: int, totalGlobalMem: int, name: str) -> None:
        """
        Implicit aggregate constructor.
        """
    def assign(self, other: ConstDeviceInfo) -> DeviceInfo:
        ...
    @property
    def computeMajor(self) -> int:
        """
        compute capability major version
        """
    @computeMajor.setter
    def computeMajor(self, arg1: int) -> None:
        ...
    @property
    def computeMinor(self) -> int:
        """
        compute capability minor version
        """
    @computeMinor.setter
    def computeMinor(self, arg1: int) -> None:
        ...
    @property
    def driverVersion(self) -> int:
        """
        maximum CUDA version supported by the driver
        """
    @driverVersion.setter
    def driverVersion(self, arg1: int) -> None:
        ...
    @property
    def name(self) -> str:
        """
        name of the device
        """
    @name.setter
    def name(self, arg1: str) -> None:
        ...
    @property
    def runtimeVersion(self) -> int:
        """
        application's CUDA version
        """
    @runtimeVersion.setter
    def runtimeVersion(self, arg1: int) -> None:
        ...
    @property
    def totalGlobalMem(self) -> int:
        """
        global memory on device in bytes (not all is available for our process)
        """
    @totalGlobalMem.setter
    def totalGlobalMem(self, arg1: int) -> None:
        ...
class ConstFastWindingNumber(meshlib.mrmeshpy.ConstIFastWindingNumber, meshlib.mrmeshpy.ConstIFastWindingNumberByParts):
    """
    Generated from:  MR::Cuda::FastWindingNumber
    
    the class for fast approximate computation of winding number for a mesh (using its AABB tree)
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    def __init__(self, *args, **kwargs):
        """
        __init__(*args, **kwargs)
        Overloaded function.
        
        1. __init__(self: meshlib.mrcudapy.ConstFastWindingNumber, mesh: meshlib.mrmeshpy.ConstMesh) -> None
        
        constructs this from AABB tree of given mesh;
        
        2. __init__(self: meshlib.mrcudapy.ConstFastWindingNumber, arg0: meshlib.mrcudapy.ConstFastWindingNumber) -> None
        
        Implicit copy constructor.
        
        3. __init__(self: meshlib.mrcudapy.ConstFastWindingNumber, : meshlib.mrcudapy.ConstFastWindingNumber) -> None
        """
class FastWindingNumber(ConstFastWindingNumber, meshlib.mrmeshpy.IFastWindingNumber, meshlib.mrmeshpy.IFastWindingNumberByParts):
    """
    Generated from:  MR::Cuda::FastWindingNumber
    
    the class for fast approximate computation of winding number for a mesh (using its AABB tree)
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    @staticmethod
    @typing.overload
    def __init__(*args, **kwargs) -> None:
        ...
    @typing.overload
    def __init__(self, mesh: meshlib.mrmeshpy.ConstMesh) -> None:
        """
        constructs this from AABB tree of given mesh;
        """
    @typing.overload
    def __init__(self, arg0: ConstFastWindingNumber) -> None:
        """
        Implicit copy constructor.
        """
    def calcFromGrid(self, res: meshlib.mrmeshpy.std_vector_float, dims: meshlib.mrmeshpy.ConstVector3i, gridToMeshXf: meshlib.mrmeshpy.ConstAffineXf3f, beta: float, cb: meshlib.mrmeshpy.Const_func_bool_from_float) -> None:
        ...
    def calcFromGridByParts(self, resFunc: meshlib.mrmeshpy.Const_func_tl_expected_void_std_string_from_Vector_float_Id_VoxelTag_Vector3_int_int, dims: meshlib.mrmeshpy.ConstVector3i, gridToMeshXf: meshlib.mrmeshpy.ConstAffineXf3f, beta: float, layerOverlap: int, cb: meshlib.mrmeshpy.Const_func_bool_from_float) -> None:
        """
        see methods' descriptions in IFastWindingNumberByParts
        """
    def calcFromGridWithDistances(self, res: meshlib.mrmeshpy.VoxelScalars, dims: meshlib.mrmeshpy.ConstVector3i, gridToMeshXf: meshlib.mrmeshpy.ConstAffineXf3f, options: meshlib.mrmeshpy.ConstDistanceToMeshOptions, cb: meshlib.mrmeshpy.Const_func_bool_from_float) -> None:
        ...
    def calcFromGridWithDistancesByParts(self, resFunc: meshlib.mrmeshpy.Const_func_tl_expected_void_std_string_from_Vector_float_Id_VoxelTag_Vector3_int_int, dims: meshlib.mrmeshpy.ConstVector3i, gridToMeshXf: meshlib.mrmeshpy.ConstAffineXf3f, options: meshlib.mrmeshpy.ConstDistanceToMeshOptions, layerOverlap: int, cb: meshlib.mrmeshpy.Const_func_bool_from_float) -> None:
        ...
    def calcFromVector(self, res: meshlib.mrmeshpy.std_vector_float, points: meshlib.mrmeshpy.Const_std_vector_Vector3_float, beta: float, skipFace: meshlib.mrmeshpy.ConstFaceId, cb: meshlib.mrmeshpy.Const_func_bool_from_float) -> None:
        """
        see methods' descriptions in IFastWindingNumber
        """
    def calcSelfIntersections(self, res: meshlib.mrmeshpy.FaceBitSet, beta: float, cb: meshlib.mrmeshpy.Const_func_bool_from_float) -> None:
        ...
class ConstPointsProjector(meshlib.mrmeshpy.ConstIPointsProjector):
    """
    Generated from:  MR::Cuda::PointsProjector
    
    CUDA-backed implementation of IPointsProjector
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    def __init__(self, *args, **kwargs):
        """
        __init__(*args, **kwargs)
        Overloaded function.
        
        1. __init__(self: meshlib.mrcudapy.ConstPointsProjector) -> None
        
        2. __init__(self: meshlib.mrcudapy.ConstPointsProjector, arg0: meshlib.mrcudapy.ConstPointsProjector) -> None
        
        Implicit copy constructor.
        
        3. __init__(self: meshlib.mrcudapy.ConstPointsProjector, : meshlib.mrcudapy.ConstPointsProjector) -> None
        """
    def findProjections(self, results: meshlib.mrmeshpy.std_vector_PointsProjectionResult, points: meshlib.mrmeshpy.ConstVertCoords, settings: meshlib.mrmeshpy.ConstFindProjectionOnPointsSettings) -> None:
        """
        computes the closest points on point cloud to given points
        """
    def projectionsHeapBytes(self, numProjections: int) -> int:
        """
        Returns amount of additional memory needed to compute projections
        """
class PointsProjector(ConstPointsProjector, meshlib.mrmeshpy.IPointsProjector):
    """
    Generated from:  MR::Cuda::PointsProjector
    
    CUDA-backed implementation of IPointsProjector
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    @staticmethod
    @typing.overload
    def __init__(*args, **kwargs) -> None:
        ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: ConstPointsProjector) -> None:
        """
        Implicit copy constructor.
        """
    def assign(self, other: ConstPointsProjector) -> PointsProjector:
        ...
    def setPointCloud(self, pointCloud: meshlib.mrmeshpy.ConstPointCloud) -> None:
        """
        sets the reference point cloud
        """
class ConstPointsToMeshProjector(meshlib.mrmeshpy.ConstIPointsToMeshProjector):
    """
    Generated from:  MR::Cuda::PointsToMeshProjector
    
    Computes the closest point on mesh to each of given points on GPU. It caches data that necessary for computing
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    def __init__(self, *args, **kwargs):
        """
        __init__(*args, **kwargs)
        Overloaded function.
        
        1. __init__(self: meshlib.mrcudapy.ConstPointsToMeshProjector) -> None
        
        2. __init__(self: meshlib.mrcudapy.ConstPointsToMeshProjector, arg0: meshlib.mrcudapy.ConstPointsToMeshProjector) -> None
        
        Implicit copy constructor.
        
        3. __init__(self: meshlib.mrcudapy.ConstPointsToMeshProjector, : meshlib.mrcudapy.ConstPointsToMeshProjector) -> None
        """
    def projectionsHeapBytes(self, numProjections: int) -> int:
        """
        Returns amount of additional memory needed to compute projections
        """
class PointsToMeshProjector(ConstPointsToMeshProjector, meshlib.mrmeshpy.IPointsToMeshProjector):
    """
    Generated from:  MR::Cuda::PointsToMeshProjector
    
    Computes the closest point on mesh to each of given points on GPU. It caches data that necessary for computing
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    @staticmethod
    @typing.overload
    def __init__(*args, **kwargs) -> None:
        ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: ConstPointsToMeshProjector) -> None:
        """
        Implicit copy constructor.
        """
    def findProjections(self, res: meshlib.mrmeshpy.std_vector_MeshProjectionResult, points: meshlib.mrmeshpy.ConstVertCoords, objXf: meshlib.mrmeshpy.ConstAffineXf3f, refObjXf: meshlib.mrmeshpy.ConstAffineXf3f, upDistLimitSq: float, loDistLimitSq: float) -> None:
        """
        <summary>
        Computes the closest point on mesh to each of given points
        </summary>
        <param name="res">vector pf projections</param>
        <param name="points">vector of points to project</param>
        <param name="objXf">transform applied to points</param>
        <param name="refObjXf">transform applied to referencing mesh</param>
        <param name="upDistLimitSq">maximal squared distance from point to mesh</param>
        <param name="loDistLimitSq">minimal squared distance from point to mesh</param>
        """
    def updateMeshData(self, mesh: meshlib.mrmeshpy.ConstMesh) -> None:
        """
        update all data related to the referencing mesh
        """
class double_output:
    """
    A helper class containing a list of scalars. This is used for functions with scalar output parameters.
    NOTE: If a function outputs an array, you must manually resize this to the correct size or risk undefined behavior.
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    values = ...
    def __init__(self, *args):
        """
        __init__(*args, **kwargs)
        Overloaded function.
        
        1. __init__(self: meshlib.mrcudapy.double_output) -> None
        
        2. __init__(self: meshlib.mrcudapy.double_output, arg0: int) -> None
        
        3. __init__(self: meshlib.mrcudapy.double_output, arg0: int, arg1: float) -> None
        """
    def __repr__(self):
        """
        __repr__(self: meshlib.mrcudapy.double_output) -> str
        """
    @property
    def value(self):
        """
        If the list contains exactly one value, returns it. Otherwise throws.
        """
    @value.setter
    def value(self, v):
        ...
class float_output:
    """
    A helper class containing a list of scalars. This is used for functions with scalar output parameters.
    NOTE: If a function outputs an array, you must manually resize this to the correct size or risk undefined behavior.
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    values = ...
    def __init__(self, *args):
        """
        __init__(*args, **kwargs)
        Overloaded function.
        
        1. __init__(self: meshlib.mrcudapy.float_output) -> None
        
        2. __init__(self: meshlib.mrcudapy.float_output, arg0: int) -> None
        
        3. __init__(self: meshlib.mrcudapy.float_output, arg0: int, arg1: float) -> None
        """
    def __repr__(self):
        """
        __repr__(self: meshlib.mrcudapy.float_output) -> str
        """
    @property
    def value(self):
        """
        If the list contains exactly one value, returns it. Otherwise throws.
        """
    @value.setter
    def value(self, v):
        ...
class int_output:
    """
    A helper class containing a list of scalars. This is used for functions with scalar output parameters.
    NOTE: If a function outputs an array, you must manually resize this to the correct size or risk undefined behavior.
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    values = ...
    def __init__(self, *args):
        """
        __init__(*args, **kwargs)
        Overloaded function.
        
        1. __init__(self: meshlib.mrcudapy.int_output) -> None
        
        2. __init__(self: meshlib.mrcudapy.int_output, arg0: int) -> None
        
        3. __init__(self: meshlib.mrcudapy.int_output, arg0: int, arg1: int) -> None
        """
    def __repr__(self):
        """
        __repr__(self: meshlib.mrcudapy.int_output) -> str
        """
    @property
    def value(self):
        """
        If the list contains exactly one value, returns it. Otherwise throws.
        """
    @value.setter
    def value(self, v):
        ...
def computeDistanceMap(mesh: meshlib.mrmeshpy.ConstMesh, params: meshlib.mrmeshpy.ConstMeshToDistanceMapParams, cb: meshlib.mrmeshpy.Const_func_bool_from_float = '{}', outSamples: meshlib.mrmeshpy.std_vector_MeshTriPointT_float = None) -> meshlib.mrmeshpy.DistanceMap:
    """
    computes distance (height) map for given projection parameters
    using float-precision for finding ray-mesh intersections, which is faster but less reliable
    """
def computeDistanceMapHeapBytes(mesh: meshlib.mrmeshpy.ConstMesh, params: meshlib.mrmeshpy.ConstMeshToDistanceMapParams, needOutSamples: bool = False) -> int:
    """
    Computes memory consumption of computeDistanceMap function
    """
def computeSkyViewFactor(terrain: meshlib.mrmeshpy.ConstMesh, samples: meshlib.mrmeshpy.ConstVertCoords, validSamples: meshlib.mrmeshpy.ConstVertBitSet, skyPatches: meshlib.mrmeshpy.Const_std_vector_SkyPatch, outSkyRays: meshlib.mrmeshpy.BitSet = None, outIntersections: meshlib.mrmeshpy.std_vector_MeshIntersectionResult = None) -> meshlib.mrmeshpy.VertScalars:
    """
    computes relative radiation in each valid sample point by emitting rays from that point in the sky:
    the radiation is 1.0f if all rays reach the sky not hitting the terrain;
    the radiation is 0.0f if all rays do not reach the sky because they are intercepted by the terrain;
    \\param outSkyRays - optional output bitset where for every valid sample i its rays are stored at indices [i*numPatches; (i+1)*numPatches),
                        0s for occluded rays (hitting the terrain) and 1s for the ones which don't hit anything and reach the sky
    \\param outIntersections - optional output vector of MeshIntersectionResult for every valid sample point
    """
def distanceMapFromContours(polyline: meshlib.mrmeshpy.ConstPolyline2, params: meshlib.mrmeshpy.ConstContourToDistanceMapParams) -> meshlib.mrmeshpy.DistanceMap:
    """
    Computes distance of 2d contours according to ContourToDistanceMapParams (works correctly only when withSign==false)
    """
def distanceMapFromContoursHeapBytes(polyline: meshlib.mrmeshpy.ConstPolyline2, params: meshlib.mrmeshpy.ConstContourToDistanceMapParams) -> int:
    """
    Computes memory consumption of distanceMapFromContours function
    """
def findProjectionOnPoints(pointCloud: meshlib.mrmeshpy.ConstPointCloud, points: meshlib.mrmeshpy.ConstVertCoords, settings: meshlib.mrmeshpy.ConstFindProjectionOnPointsSettings = ...) -> meshlib.mrmeshpy.std_vector_PointsProjectionResult:
    """
    computes the closest points on point cloud to given points
    """
def findProjectionOnPointsHeapBytes(pointCloud: meshlib.mrmeshpy.ConstPointCloud, pointsCount: int) -> int:
    """
    returns the minimal amount of free GPU memory required for \\ref MR::Cuda::findProjectionOnPoints
    """
def findSkyRays(terrain: meshlib.mrmeshpy.ConstMesh, samples: meshlib.mrmeshpy.ConstVertCoords, validSamples: meshlib.mrmeshpy.ConstVertBitSet, skyPatches: meshlib.mrmeshpy.Const_std_vector_SkyPatch, outIntersections: meshlib.mrmeshpy.std_vector_MeshIntersectionResult = None) -> meshlib.mrmeshpy.BitSet:
    """
    In each valid sample point tests the rays from that point in the sky;
    \\return bitset where for every valid sample i its rays are stored at indices [i*numPatches; (i+1)*numPatches),
            0s for occluded rays (hitting the terrain) and 1s for the ones which don't hit anything and reach the sky
    \\param outIntersections - optional output vector of MeshIntersectionResult for every valid sample point
    """
def getCudaAvailableMemory() -> int:
    """
    Returns available GPU memory in bytes
    """
def getCudaSafeMemoryLimit() -> int:
    """
    Returns maximum safe amount of free GPU memory that will be used for dynamic-sized buffers
    """
def getDeviceInfo() -> DeviceInfo:
    """
    Returns an error if CUDA is not available
    """
def isCudaAvailable(driverVersion: int_output = None, runtimeVersion: int_output = None, computeMajor: int_output = None, computeMinor: int_output = None) -> bool:
    """
    Returns true if Cuda is present on this GPU
    optional out maximum driver supported version
    optional out current runtime version
    optional out compute capability major version
    optional out compute capability minor version
    """
def loadMRCudaDll() -> None:
    """
    call this function to load MRCuda shared library
    """
def maxBufferSize(availableBytes: int, elementCount: int, elementBytes: int) -> int:
    """
    Returns maximum buffer size in elements that can be allocated with given memory limit
    """
@typing.overload
def maxBufferSizeAlignedByBlock(availableBytes: int, blockDims: meshlib.mrmeshpy.ConstVector2i, elementBytes: int) -> int:
    """
    Returns maximum buffer size in elements that can be allocated with given memory limit
    The size is aligned to the block dimensions
    """
@typing.overload
def maxBufferSizeAlignedByBlock(availableBytes: int, blockDims: meshlib.mrmeshpy.ConstVector3i, elementBytes: int) -> int:
    ...
def negatePicture(image: meshlib.mrmeshpy.Image) -> None:
    """
    This function inverts Color value (255 - value in each channel except alpha)
    """
def pointsToDistanceVolume(cloud: meshlib.mrmeshpy.ConstPointCloud, params: meshlib.mrmeshpy.ConstPointsToDistanceVolumeParams) -> meshlib.mrmeshpy.SimpleVolumeMinMax:
    """
    makes SimpleVolume filled with signed distances to points with normals
    """
def pointsToDistanceVolumeByParts(cloud: meshlib.mrmeshpy.ConstPointCloud, params: meshlib.mrmeshpy.ConstPointsToDistanceVolumeParams, addPart: meshlib.mrmeshpy.Const_func_tl_expected_void_std_string_from_VoxelsVolumeMinMax_Vector_float_Id_VoxelTag_int, layerOverlap: int) -> None:
    """
    makes SimpleVolume filled with signed distances to points with normals
    populate the volume by parts to the given callback
    """
def pointsToDistanceVolumeMemory(cloud: meshlib.mrmeshpy.ConstPointCloud, dims: meshlib.mrmeshpy.ConstVector3i, ptNormals: meshlib.mrmeshpy.ConstVertCoords) -> int:
    """
    returns the minimal amount of free GPU memory required to build a distance volume with given dimensions
    """
__mrbind_cpp_api__: typing.Any
