from __future__ import annotations
import atexit as _atexit
import builtins
import enum
import meshlib.mrmeshpy
import typing
__all__: list[str] = ['ConstUiEntry', 'ConstUiValueInt', 'ConstUiValueReal', 'ConstUiValueString', 'ConstUiValueUint', 'ConstViewer', 'ConstViewerLaunchParams', 'ConstViewerSetup', 'ConstViewport', 'ConstViewportFitDataParams', 'Const_std_vector_PythonViewer_UiEntry', 'Const_std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry', 'KeyMod', 'MouseButton', 'UiEntry', 'UiEntryType', 'UiValueInt', 'UiValueReal', 'UiValueString', 'UiValueUint', 'Viewer', 'ViewerLaunchParams', 'ViewerLaunchParamsMode', 'ViewerSetup', 'Viewport', 'ViewportFitDataParams', 'ViewportFitMode', 'addDistanceMapToScene', 'addLinesToScene', 'addMeshToScene', 'addPointCloudToScene', 'addVoxelsToScene', 'clearScene', 'double_output', 'float_output', 'getPrimaryCtrlKeyMod', 'getSelectedDistanceMaps', 'getSelectedMeshEdges', 'getSelectedMeshFaces', 'getSelectedMeshes', 'getSelectedObjects', 'getSelectedPointCloudPoints', 'getSelectedPointClouds', 'getSelectedPolylines', 'getSelectedVoxels', 'launch', 'modifySelectedMesh', 'runFromGUIThread', 'selectByName', 'selectByType', 'setSelectedMeshEdges', 'setSelectedMeshFaces', 'setSelectedPointCloudPoints', 'showViewer', 'std_vector_PythonViewer_UiEntry', 'std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry', 'uiListAllEntries', 'uiListEntries', 'uiPressButton', 'uiReadValueInt', 'uiReadValueReal', 'uiReadValueString', 'uiReadValueUint', 'uiWriteValue', 'unselectAll']
class KeyMod(enum.IntFlag):
    """
    Members:
    
      Empty
    
      Ctrl
    
      Super
    
      Shift
    
      Alt
    """
    Alt: typing.ClassVar[KeyMod]
    Ctrl: typing.ClassVar[KeyMod]
    Empty: typing.ClassVar[KeyMod]
    Shift: typing.ClassVar[KeyMod]
    Super: typing.ClassVar[KeyMod]
    _all_bits_: typing.ClassVar[int] = 15
    _boundary_: typing.ClassVar[enum.FlagBoundary]
    _flag_mask_: typing.ClassVar[int] = 15
    _inverted_ = None
    _member_map_: typing.ClassVar[dict]
    _member_names_: typing.ClassVar[list] = ['Ctrl', 'Super', 'Shift', 'Alt']
    _singles_mask_: typing.ClassVar[int] = 15
    _unhashable_values_: typing.ClassVar[list] = list()
    _use_args_: typing.ClassVar[bool] = True
    _value2member_map_: typing.ClassVar[dict]
    _member_type_ = builtins.int
    @staticmethod
    def _generate_next_value_(name, start, count, last_values):
        """
                Generate the next value when not given.
        
                name: the name of the member
                start: the initial start value or None
                count: the number of existing members
                last_values: the last value assigned or None
                
        """
    @staticmethod
    def _new_member_(type, *args, **kwargs):
        """
        Create and return a new object.  See help(type) for accurate signature.
        """
    @classmethod
    def __new__(cls, value):
        ...
    @classmethod
    def _iter_member_(cls, value):
        """
                Extract all members from the value in definition order.
                
        """
    def __and__(self, b: KeyMod) -> KeyMod:
        ...
    def __format__(self, format_spec):
        ...
    def __iand__(self, other, f = ...):
        """
        __iand__(self: meshlib.mrviewerpy.KeyMod, b: meshlib.mrviewerpy.KeyMod) -> meshlib.mrviewerpy.KeyMod
        """
    def __imul__(self, other, f = ...):
        """
        __imul__(self: meshlib.mrviewerpy.KeyMod, b: bool) -> meshlib.mrviewerpy.KeyMod
        """
    def __invert__(self) -> KeyMod:
        ...
    def __ior__(self, other, f = ...):
        """
        __ior__(self: meshlib.mrviewerpy.KeyMod, b: meshlib.mrviewerpy.KeyMod) -> meshlib.mrviewerpy.KeyMod
        """
    def __ixor__(self, other, f = enum.Flag.__xor__):
        """
        """
    def __mul__(self, b: bool) -> KeyMod:
        ...
    def __or__(self, b: KeyMod) -> KeyMod:
        ...
    def __rand__(self, other):
        ...
    def __rmul__(self, b: bool) -> KeyMod:
        ...
    def __ror__(self, other):
        ...
    def __rxor__(self, other):
        ...
    def __str__(self):
        ...
    def __xor__(self, other):
        ...
    def _value_repr_(self):
        """
        Return repr(self).
        """
class MouseButton(enum.IntEnum):
    """
    Members:
    
      Left
    
      Right
    
      Middle
    """
    Left: typing.ClassVar[MouseButton]
    Middle: typing.ClassVar[MouseButton]
    Right: typing.ClassVar[MouseButton]
    _member_map_: typing.ClassVar[dict]
    _member_names_: typing.ClassVar[list] = ['Left', 'Right', 'Middle']
    _unhashable_values_: typing.ClassVar[list] = list()
    _use_args_: typing.ClassVar[bool] = True
    _value2member_map_: typing.ClassVar[dict]
    _member_type_ = builtins.int
    @staticmethod
    def _generate_next_value_(name, start, count, last_values):
        """
                Generate the next value when not given.
        
                name: the name of the member
                start: the initial start value or None
                count: the number of existing members
                last_values: the list of values assigned
                
        """
    @staticmethod
    def _new_member_(type, *args, **kwargs):
        """
        Create and return a new object.  See help(type) for accurate signature.
        """
    @classmethod
    def __new__(cls, value):
        ...
    @classmethod
    def _missing_(cls, value):
        ...
    def __format__(self, format_spec):
        ...
    def __str__(self):
        ...
    def _value_repr_(self):
        """
        Return repr(self).
        """
class ConstUiEntry:
    """
    Generated from:  MR::PythonViewer::UiEntry
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    _offsetof_name: typing.ClassVar[int] = 0
    _offsetof_status: typing.ClassVar[int] = 40
    _offsetof_type: typing.ClassVar[int] = 32
    @staticmethod
    def __repr__(e):
        ...
    def __init__(self, *args, **kwargs):
        """
        __init__(*args, **kwargs)
        Overloaded function.
        
        1. __init__(self: meshlib.mrviewerpy.ConstUiEntry) -> None
        
        2. __init__(self: meshlib.mrviewerpy.ConstUiEntry, arg0: meshlib.mrviewerpy.ConstUiEntry) -> None
        
        Implicit copy constructor.
        
        3. __init__(self: meshlib.mrviewerpy.ConstUiEntry, name: str, type: meshlib.mrviewerpy.UiEntryType, status: str) -> None
        
        Implicit aggregate constructor.
        
        4. __init__(self: meshlib.mrviewerpy.ConstUiEntry, : meshlib.mrviewerpy.ConstUiEntry) -> None
        """
    @property
    def name(self) -> str:
        ...
    @property
    def status(self) -> str:
        ...
    @property
    def type(self) -> UiEntryType:
        ...
class UiEntry(ConstUiEntry):
    """
    Generated from:  MR::PythonViewer::UiEntry
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    name: str
    status: str
    type: UiEntryType
    @staticmethod
    @typing.overload
    def __init__(*args, **kwargs) -> None:
        ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: ConstUiEntry) -> None:
        """
        Implicit copy constructor.
        """
    @typing.overload
    def __init__(self, name: str, type: UiEntryType, status: str) -> None:
        """
        Implicit aggregate constructor.
        """
    def assign(self, other: ConstUiEntry) -> UiEntry:
        ...
class UiEntryType(enum.IntEnum):
    """
    Members:
    
      button
    
      group
    
      valueInt
    
      valueUint
    
      valueReal
    
      valueString
    """
    _member_map_: typing.ClassVar[dict]
    _member_names_: typing.ClassVar[list] = ['button', 'group', 'valueInt', 'valueUint', 'valueReal', 'valueString']
    _unhashable_values_: typing.ClassVar[list] = list()
    _use_args_: typing.ClassVar[bool] = True
    _value2member_map_: typing.ClassVar[dict]
    button: typing.ClassVar[UiEntryType]
    group: typing.ClassVar[UiEntryType]
    valueInt: typing.ClassVar[UiEntryType]
    valueReal: typing.ClassVar[UiEntryType]
    valueString: typing.ClassVar[UiEntryType]
    valueUint: typing.ClassVar[UiEntryType]
    _member_type_ = builtins.int
    @staticmethod
    def _generate_next_value_(name, start, count, last_values):
        """
                Generate the next value when not given.
        
                name: the name of the member
                start: the initial start value or None
                count: the number of existing members
                last_values: the list of values assigned
                
        """
    @staticmethod
    def _new_member_(type, *args, **kwargs):
        """
        Create and return a new object.  See help(type) for accurate signature.
        """
    @classmethod
    def __new__(cls, value):
        ...
    @classmethod
    def _missing_(cls, value):
        ...
    def __format__(self, format_spec):
        ...
    def __str__(self):
        ...
    def _value_repr_(self):
        """
        Return repr(self).
        """
class ConstUiValueInt:
    """
    Generated from:  MR::PythonViewer::UiValueInt
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    _offsetof_max: typing.ClassVar[int] = 16
    _offsetof_min: typing.ClassVar[int] = 8
    _offsetof_value: typing.ClassVar[int] = 0
    def __init__(self, *args, **kwargs):
        """
        __init__(*args, **kwargs)
        Overloaded function.
        
        1. __init__(self: meshlib.mrviewerpy.ConstUiValueInt) -> None
        
        2. __init__(self: meshlib.mrviewerpy.ConstUiValueInt, arg0: meshlib.mrviewerpy.ConstUiValueInt) -> None
        
        Implicit copy constructor.
        
        3. __init__(self: meshlib.mrviewerpy.ConstUiValueInt, value: int, min: int, max: int) -> None
        
        Implicit aggregate constructor.
        
        4. __init__(self: meshlib.mrviewerpy.ConstUiValueInt, : meshlib.mrviewerpy.ConstUiValueInt) -> None
        """
    @property
    def max(self) -> int:
        ...
    @property
    def min(self) -> int:
        ...
    @property
    def value(self) -> int:
        ...
class UiValueInt(ConstUiValueInt):
    """
    Generated from:  MR::PythonViewer::UiValueInt
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    max: int
    min: int
    value: int
    @staticmethod
    @typing.overload
    def __init__(*args, **kwargs) -> None:
        ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: ConstUiValueInt) -> None:
        """
        Implicit copy constructor.
        """
    @typing.overload
    def __init__(self, value: int, min: int, max: int) -> None:
        """
        Implicit aggregate constructor.
        """
    def assign(self, other: ConstUiValueInt) -> UiValueInt:
        ...
class ConstUiValueReal:
    """
    Generated from:  MR::PythonViewer::UiValueReal
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    _offsetof_max: typing.ClassVar[int] = 16
    _offsetof_min: typing.ClassVar[int] = 8
    _offsetof_value: typing.ClassVar[int] = 0
    def __init__(self, *args, **kwargs):
        """
        __init__(*args, **kwargs)
        Overloaded function.
        
        1. __init__(self: meshlib.mrviewerpy.ConstUiValueReal) -> None
        
        2. __init__(self: meshlib.mrviewerpy.ConstUiValueReal, arg0: meshlib.mrviewerpy.ConstUiValueReal) -> None
        
        Implicit copy constructor.
        
        3. __init__(self: meshlib.mrviewerpy.ConstUiValueReal, value: float, min: float, max: float) -> None
        
        Implicit aggregate constructor.
        
        4. __init__(self: meshlib.mrviewerpy.ConstUiValueReal, : meshlib.mrviewerpy.ConstUiValueReal) -> None
        """
    @property
    def max(self) -> float:
        ...
    @property
    def min(self) -> float:
        ...
    @property
    def value(self) -> float:
        ...
class UiValueReal(ConstUiValueReal):
    """
    Generated from:  MR::PythonViewer::UiValueReal
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    max: float
    min: float
    value: float
    @staticmethod
    @typing.overload
    def __init__(*args, **kwargs) -> None:
        ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: ConstUiValueReal) -> None:
        """
        Implicit copy constructor.
        """
    @typing.overload
    def __init__(self, value: float, min: float, max: float) -> None:
        """
        Implicit aggregate constructor.
        """
    def assign(self, other: ConstUiValueReal) -> UiValueReal:
        ...
class ConstUiValueString:
    """
    Generated from:  MR::PythonViewer::UiValueString
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    _offsetof_allowed: typing.ClassVar[int] = 32
    _offsetof_value: typing.ClassVar[int] = 0
    def __init__(self, *args, **kwargs):
        """
        __init__(*args, **kwargs)
        Overloaded function.
        
        1. __init__(self: meshlib.mrviewerpy.ConstUiValueString) -> None
        
        2. __init__(self: meshlib.mrviewerpy.ConstUiValueString, arg0: meshlib.mrviewerpy.ConstUiValueString) -> None
        
        Implicit copy constructor.
        
        3. __init__(self: meshlib.mrviewerpy.ConstUiValueString, value: str, allowed: meshlib.mrmeshpy.Const_std_optional_std_vector_std_string) -> None
        
        Implicit aggregate constructor.
        
        4. __init__(self: meshlib.mrviewerpy.ConstUiValueString, : meshlib.mrviewerpy.ConstUiValueString) -> None
        """
    @property
    def allowed(self):
        ...
    @property
    def value(self) -> str:
        ...
class UiValueString(ConstUiValueString):
    """
    Generated from:  MR::PythonViewer::UiValueString
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    value: str
    @staticmethod
    @typing.overload
    def __init__(*args, **kwargs) -> None:
        ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: ConstUiValueString) -> None:
        """
        Implicit copy constructor.
        """
    @typing.overload
    def __init__(self, value: str, allowed: meshlib.mrmeshpy.Const_std_optional_std_vector_std_string) -> None:
        """
        Implicit aggregate constructor.
        """
    def assign(self, other: ConstUiValueString) -> UiValueString:
        ...
    @property
    def allowed(self) -> meshlib.mrmeshpy.std_optional_std_vector_std_string:
        ...
    @allowed.setter
    def allowed(self, arg1: meshlib.mrmeshpy.Const_std_optional_std_vector_std_string) -> None:
        ...
class ConstUiValueUint:
    """
    Generated from:  MR::PythonViewer::UiValueUint
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    _offsetof_max: typing.ClassVar[int] = 16
    _offsetof_min: typing.ClassVar[int] = 8
    _offsetof_value: typing.ClassVar[int] = 0
    def __init__(self, *args, **kwargs):
        """
        __init__(*args, **kwargs)
        Overloaded function.
        
        1. __init__(self: meshlib.mrviewerpy.ConstUiValueUint) -> None
        
        2. __init__(self: meshlib.mrviewerpy.ConstUiValueUint, arg0: meshlib.mrviewerpy.ConstUiValueUint) -> None
        
        Implicit copy constructor.
        
        3. __init__(self: meshlib.mrviewerpy.ConstUiValueUint, value: int, min: int, max: int) -> None
        
        Implicit aggregate constructor.
        
        4. __init__(self: meshlib.mrviewerpy.ConstUiValueUint, : meshlib.mrviewerpy.ConstUiValueUint) -> None
        """
    @property
    def max(self) -> int:
        ...
    @property
    def min(self) -> int:
        ...
    @property
    def value(self) -> int:
        ...
class UiValueUint(ConstUiValueUint):
    """
    Generated from:  MR::PythonViewer::UiValueUint
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    max: int
    min: int
    value: int
    @staticmethod
    @typing.overload
    def __init__(*args, **kwargs) -> None:
        ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: ConstUiValueUint) -> None:
        """
        Implicit copy constructor.
        """
    @typing.overload
    def __init__(self, value: int, min: int, max: int) -> None:
        """
        Implicit aggregate constructor.
        """
    def assign(self, other: ConstUiValueUint) -> UiValueUint:
        ...
class ConstViewer:
    """
    Generated from:  MR::PythonViewer::Viewer
    
    GLFW-based mesh viewer
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    def __init__(self, *args, **kwargs):
        """
        __init__(*args, **kwargs)
        Overloaded function.
        
        1. __init__(self: meshlib.mrviewerpy.ConstViewer) -> None
        
        2. __init__(self: meshlib.mrviewerpy.ConstViewer, arg0: meshlib.mrviewerpy.ConstViewer) -> None
        
        Implicit copy constructor.
        
        3. __init__(self: meshlib.mrviewerpy.ConstViewer) -> None
        
        Implicit aggregate constructor.
        
        4. __init__(self: meshlib.mrviewerpy.ConstViewer, : meshlib.mrviewerpy.ConstViewer) -> None
        """
    def captureScreenShot(self, path: str) -> None:
        """
        Captures part of window (redraw 3d scene over UI (without redrawing UI))
        """
    def captureUIScreenShot(self, path: str) -> None:
        """
        Captures full window screenshot with UI
        """
    def getMousePos(self) -> meshlib.mrmeshpy.Vector2f:
        """
        Get the current mouse position.
        """
    def incrementForceRedrawFrames(self, num: int = 1, swapOnLastOnly: bool = False) -> None:
        """
        Increment number of forced frames to redraw in event loop
        if `swapOnLastOnly` only last forced frame will be present on screen and all previous will not
        """
    def mouseDown(self, button: MouseButton, modifier: KeyMod = 'MR::PythonViewer::KeyMod::Empty') -> None:
        """
        Simulate mouse down event.
        """
    def mouseMove(self, x: int, y: int) -> None:
        """
        Simulate mouse move event.
        NOTE: Some plugins need at least TWO `mouseMove()`s in a row (possibly with the same position). If you're having issues, try sending two events.
        """
    def mouseUp(self, button: MouseButton, modifier: KeyMod = 'MR::PythonViewer::KeyMod::Empty') -> None:
        """
        Simulate mouse up event.
        """
    def preciseFitDataViewport(self, vpList: meshlib.mrmeshpy.ConstViewportMask = 'MR::ViewportMask::all()', params: ConstViewportFitDataParams = ...) -> None:
        """
        Calls fitData and change FOV to match the screen size then
        params - params fit data
        """
    def showSceneTree(self, show: bool) -> None:
        """
        Shows or hide scene tree
        """
    def shutdown(self, exitCode: int = 0, interruptible: bool = True) -> None:
        """
        sets stop event loop flag (this flag is glfwShouldWindowClose equivalent); the viewer's launch then returns exitCode; interruptible = False: no interruptCloseSignal slot can cancel the stop
        """
    def skipFrames(self, frames: int) -> None:
        ...
    def viewport(self, viewportId: meshlib.mrmeshpy.ConstViewportId = ...) -> Viewport:
        """
        Return the current viewport, or the viewport corresponding to a given unique identifier
        	viewportId - unique identifier corresponding to the desired viewport (current viewport if 0)
        """
    def viewportToScreen(self, viewportPoint: meshlib.mrmeshpy.ConstVector3f, id: meshlib.mrmeshpy.ConstViewportId) -> meshlib.mrmeshpy.Vector3f:
        """
        Convert viewport coordinates to to screen coordinates
        """
class Viewer(ConstViewer):
    """
    Generated from:  MR::PythonViewer::Viewer
    
    GLFW-based mesh viewer
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    @staticmethod
    @typing.overload
    def __init__(*args, **kwargs) -> None:
        ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: ConstViewer) -> None:
        """
        Implicit copy constructor.
        """
    @typing.overload
    def __init__(self) -> None:
        """
        Implicit aggregate constructor.
        """
    def assign(self, other: ConstViewer) -> Viewer:
        ...
class ConstViewerLaunchParams:
    """
    Generated from:  MR::PythonViewer::ViewerLaunchParams
    
    This struct contains rules for viewer launch
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    _offsetof_animationMaxFps: typing.ClassVar[int] = 0
    _offsetof_fullscreen: typing.ClassVar[int] = 4
    _offsetof_height: typing.ClassVar[int] = 12
    _offsetof_isAnimating: typing.ClassVar[int] = 16
    _offsetof_name: typing.ClassVar[int] = 24
    _offsetof_width: typing.ClassVar[int] = 8
    _offsetof_windowMode: typing.ClassVar[int] = 56
    def __init__(self, *args, **kwargs):
        """
        __init__(*args, **kwargs)
        Overloaded function.
        
        1. __init__(self: meshlib.mrviewerpy.ConstViewerLaunchParams) -> None
        
        2. __init__(self: meshlib.mrviewerpy.ConstViewerLaunchParams, arg0: meshlib.mrviewerpy.ConstViewerLaunchParams) -> None
        
        Implicit copy constructor.
        
        3. __init__(self: meshlib.mrviewerpy.ConstViewerLaunchParams, animationMaxFps: int, fullscreen: bool, width: int, height: int, isAnimating: bool, name: str, windowMode: meshlib.mrviewerpy.ViewerLaunchParamsMode) -> None
        
        Implicit aggregate constructor.
        
        4. __init__(self: meshlib.mrviewerpy.ConstViewerLaunchParams, : meshlib.mrviewerpy.ConstViewerLaunchParams) -> None
        """
    @property
    def animationMaxFps(self) -> int:
        """
        max fps if animating
        """
    @property
    def fullscreen(self) -> bool:
        """
        if true starts fullscreen
        """
    @property
    def height(self) -> int:
        ...
    @property
    def isAnimating(self) -> bool:
        """
        if true - calls render without system events
        """
    @property
    def name(self) -> str:
        """
        Window name
        """
    @property
    def width(self) -> int:
        ...
    @property
    def windowMode(self) -> ViewerLaunchParamsMode:
        ...
class ViewerLaunchParams(ConstViewerLaunchParams):
    """
    Generated from:  MR::PythonViewer::ViewerLaunchParams
    
    This struct contains rules for viewer launch
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    height: int
    width: int
    windowMode: ViewerLaunchParamsMode
    @staticmethod
    @typing.overload
    def __init__(*args, **kwargs) -> None:
        ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: ConstViewerLaunchParams) -> None:
        """
        Implicit copy constructor.
        """
    @typing.overload
    def __init__(self, animationMaxFps: int, fullscreen: bool, width: int, height: int, isAnimating: bool, name: str, windowMode: ViewerLaunchParamsMode) -> None:
        """
        Implicit aggregate constructor.
        """
    def assign(self, other: ConstViewerLaunchParams) -> ViewerLaunchParams:
        ...
    @property
    def animationMaxFps(self) -> int:
        """
        max fps if animating
        """
    @animationMaxFps.setter
    def animationMaxFps(self, arg1: int) -> None:
        ...
    @property
    def fullscreen(self) -> bool:
        """
        if true starts fullscreen
        """
    @fullscreen.setter
    def fullscreen(self, arg1: bool) -> None:
        ...
    @property
    def isAnimating(self) -> bool:
        """
        if true - calls render without system events
        """
    @isAnimating.setter
    def isAnimating(self, arg1: bool) -> None:
        ...
    @property
    def name(self) -> str:
        """
        Window name
        """
    @name.setter
    def name(self, arg1: str) -> None:
        ...
class ViewerLaunchParamsMode(enum.IntEnum):
    """
    Members:
    
      Show : Show window immediately
    
      HideInit : Show window after init
    
      Hide : Don't show window
    
      TryHidden : Launches in "Hide" mode if OpenGL is present and "NoWindow" if it is not
    
      NoWindow : Don't initialize GL window (don't call GL functions)(force `isAnimating`)
    """
    Hide: typing.ClassVar[ViewerLaunchParamsMode]
    HideInit: typing.ClassVar[ViewerLaunchParamsMode]
    NoWindow: typing.ClassVar[ViewerLaunchParamsMode]
    Show: typing.ClassVar[ViewerLaunchParamsMode]
    TryHidden: typing.ClassVar[ViewerLaunchParamsMode]
    _member_map_: typing.ClassVar[dict]
    _member_names_: typing.ClassVar[list] = ['Show', 'HideInit', 'Hide', 'TryHidden', 'NoWindow']
    _unhashable_values_: typing.ClassVar[list] = list()
    _use_args_: typing.ClassVar[bool] = True
    _value2member_map_: typing.ClassVar[dict]
    _member_type_ = builtins.int
    @staticmethod
    def _generate_next_value_(name, start, count, last_values):
        """
                Generate the next value when not given.
        
                name: the name of the member
                start: the initial start value or None
                count: the number of existing members
                last_values: the list of values assigned
                
        """
    @staticmethod
    def _new_member_(type, *args, **kwargs):
        """
        Create and return a new object.  See help(type) for accurate signature.
        """
    @classmethod
    def __new__(cls, value):
        ...
    @classmethod
    def _missing_(cls, value):
        ...
    def __format__(self, format_spec):
        ...
    def __str__(self):
        ...
    def _value_repr_(self):
        """
        Return repr(self).
        """
class ConstViewerSetup:
    """
    Generated from:  MR::PythonViewer::ViewerSetup
    
    viewer setup class for minimal configuration
    only loads config file (if available) and configures the scene and mouse controls
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    def __init__(self, *args, **kwargs):
        """
        __init__(*args, **kwargs)
        Overloaded function.
        
        1. __init__(self: meshlib.mrviewerpy.ConstViewerSetup) -> None
        
        2. __init__(self: meshlib.mrviewerpy.ConstViewerSetup, arg0: meshlib.mrviewerpy.ConstViewerSetup) -> None
        
        Implicit copy constructor.
        
        3. __init__(self: meshlib.mrviewerpy.ConstViewerSetup) -> None
        
        Implicit aggregate constructor.
        
        4. __init__(self: meshlib.mrviewerpy.ConstViewerSetup, : meshlib.mrviewerpy.ConstViewerSetup) -> None
        """
class ViewerSetup(ConstViewerSetup):
    """
    Generated from:  MR::PythonViewer::ViewerSetup
    
    viewer setup class for minimal configuration
    only loads config file (if available) and configures the scene and mouse controls
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    @staticmethod
    @typing.overload
    def __init__(*args, **kwargs) -> None:
        ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: ConstViewerSetup) -> None:
        """
        Implicit copy constructor.
        """
    @typing.overload
    def __init__(self) -> None:
        """
        Implicit aggregate constructor.
        """
    def assign(self, other: ConstViewerSetup) -> ViewerSetup:
        ...
class ConstViewport:
    """
    Generated from:  MR::PythonViewer::Viewport
    
    Viewport is a rectangular area, in which the objects of interest are going to be rendered.
    An application can have a number of viewports each with its own ID.
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    _offsetof_id: typing.ClassVar[int] = 0
    def __init__(self, *args, **kwargs):
        """
        __init__(*args, **kwargs)
        Overloaded function.
        
        1. __init__(self: meshlib.mrviewerpy.ConstViewport, id: meshlib.mrmeshpy.ConstViewportId) -> None
        
        2. __init__(self: meshlib.mrviewerpy.ConstViewport, arg0: meshlib.mrviewerpy.ConstViewport) -> None
        
        Implicit copy constructor.
        
        3. __init__(self: meshlib.mrviewerpy.ConstViewport, : meshlib.mrviewerpy.ConstViewport) -> None
        """
    def cameraLookAlong(self, dir: meshlib.mrmeshpy.ConstVector3f, up: meshlib.mrmeshpy.ConstVector3f) -> None:
        """
        Set camera look direction and up direction (they should be perpendicular)
        this function changes camera position and do not change camera spot (0,0,0) by default
        to change camera position use setCameraTranslation after this function
        """
    def cameraRotateAround(self, axis: meshlib.mrmeshpy.ConstLine3f, angle: float) -> None:
        """
        Rotates camera around axis +direction applied to axis point
        note: this can make camera clip objects (as far as distance to scene center is not fixed)
        """
    def projectToViewportSpace(self, input: meshlib.mrmeshpy.ConstVector3f) -> meshlib.mrmeshpy.Vector3f:
        """
        Project world space point to viewport coordinates (in pixels), (0,0) will be at the top-left corner of the viewport.
        """
    @property
    def id(self) -> meshlib.mrmeshpy.ConstViewportId:
        ...
class Viewport(ConstViewport):
    """
    Generated from:  MR::PythonViewer::Viewport
    
    Viewport is a rectangular area, in which the objects of interest are going to be rendered.
    An application can have a number of viewports each with its own ID.
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    @staticmethod
    @typing.overload
    def __init__(*args, **kwargs) -> None:
        ...
    @typing.overload
    def __init__(self, id: meshlib.mrmeshpy.ConstViewportId) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: ConstViewport) -> None:
        """
        Implicit copy constructor.
        """
class ConstViewportFitDataParams:
    """
    Generated from:  MR::PythonViewer::ViewportFitDataParams
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    _offsetof_factor: typing.ClassVar[int] = 0
    _offsetof_mode: typing.ClassVar[int] = 8
    _offsetof_snapView: typing.ClassVar[int] = 4
    def __init__(self, *args, **kwargs):
        """
        __init__(*args, **kwargs)
        Overloaded function.
        
        1. __init__(self: meshlib.mrviewerpy.ConstViewportFitDataParams) -> None
        
        2. __init__(self: meshlib.mrviewerpy.ConstViewportFitDataParams, arg0: meshlib.mrviewerpy.ConstViewportFitDataParams) -> None
        
        Implicit copy constructor.
        
        3. __init__(self: meshlib.mrviewerpy.ConstViewportFitDataParams, factor: float, snapView: bool, mode: meshlib.mrviewerpy.ViewportFitMode) -> None
        
        Implicit aggregate constructor.
        
        4. __init__(self: meshlib.mrviewerpy.ConstViewportFitDataParams, : meshlib.mrviewerpy.ConstViewportFitDataParams) -> None
        """
    @property
    def factor(self) -> float:
        """
        part of the screen for scene location
        """
    @property
    def mode(self) -> ViewportFitMode:
        """
        fit mode
        """
    @property
    def snapView(self) -> bool:
        """
        snapView - to snap camera angle to closest canonical quaternion
        """
class ViewportFitDataParams(ConstViewportFitDataParams):
    """
    Generated from:  MR::PythonViewer::ViewportFitDataParams
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    @staticmethod
    @typing.overload
    def __init__(*args, **kwargs) -> None:
        ...
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: ConstViewportFitDataParams) -> None:
        """
        Implicit copy constructor.
        """
    @typing.overload
    def __init__(self, factor: float, snapView: bool, mode: ViewportFitMode) -> None:
        """
        Implicit aggregate constructor.
        """
    def assign(self, other: ConstViewportFitDataParams) -> ViewportFitDataParams:
        ...
    @property
    def factor(self) -> float:
        """
        part of the screen for scene location
        """
    @factor.setter
    def factor(self, arg1: float) -> None:
        ...
    @property
    def mode(self) -> ViewportFitMode:
        """
        fit mode
        """
    @mode.setter
    def mode(self, arg1: ViewportFitMode) -> None:
        ...
    @property
    def snapView(self) -> bool:
        """
        snapView - to snap camera angle to closest canonical quaternion
        """
    @snapView.setter
    def snapView(self, arg1: bool) -> None:
        ...
class ViewportFitMode(enum.IntEnum):
    """
    Members:
    
      Visible : fit all visible objects
    
      SelectedPrimitives : fit only selected primitives
    
      SelectedObjects : fit only selected objects
    """
    SelectedObjects: typing.ClassVar[ViewportFitMode]
    SelectedPrimitives: typing.ClassVar[ViewportFitMode]
    Visible: typing.ClassVar[ViewportFitMode]
    _member_map_: typing.ClassVar[dict]
    _member_names_: typing.ClassVar[list] = ['Visible', 'SelectedPrimitives', 'SelectedObjects']
    _unhashable_values_: typing.ClassVar[list] = list()
    _use_args_: typing.ClassVar[bool] = True
    _value2member_map_: typing.ClassVar[dict]
    _member_type_ = builtins.int
    @staticmethod
    def _generate_next_value_(name, start, count, last_values):
        """
                Generate the next value when not given.
        
                name: the name of the member
                start: the initial start value or None
                count: the number of existing members
                last_values: the list of values assigned
                
        """
    @staticmethod
    def _new_member_(type, *args, **kwargs):
        """
        Create and return a new object.  See help(type) for accurate signature.
        """
    @classmethod
    def __new__(cls, value):
        ...
    @classmethod
    def _missing_(cls, value):
        ...
    def __format__(self, format_spec):
        ...
    def __str__(self):
        ...
    def _value_repr_(self):
        """
        Return repr(self).
        """
class Const_std_vector_PythonViewer_UiEntry:
    __slots__: typing.ClassVar[tuple] = tuple()
    element_type_byte_size: typing.ClassVar[int] = 72
    def __bool__(self):
        """
        __bool__(self: meshlib.mrviewerpy.Const_std_vector_PythonViewer_UiEntry) -> bool
        
        Check whether the list is nonempty
        """
    def __getitem__(self, i):
        """
        __getitem__(*args, **kwargs)
        Overloaded function.
        
        1. __getitem__(self: meshlib.mrviewerpy.Const_std_vector_PythonViewer_UiEntry, s: slice) -> meshlib.mrviewerpy.std_vector_PythonViewer_UiEntry
        
        Retrieve list elements using a slice object
        
        2. __getitem__(self: meshlib.mrviewerpy.Const_std_vector_PythonViewer_UiEntry, arg0: int) -> meshlib.mrviewerpy.ConstUiEntry
        """
    def __init__(self, *args, **kwargs):
        """
        __init__(*args, **kwargs)
        Overloaded function.
        
        1. __init__(self: meshlib.mrviewerpy.Const_std_vector_PythonViewer_UiEntry) -> None
        
        2. __init__(self: meshlib.mrviewerpy.Const_std_vector_PythonViewer_UiEntry, arg0: Iterable) -> None
        
        3. __init__(self: meshlib.mrviewerpy.Const_std_vector_PythonViewer_UiEntry, arg0: meshlib.mrviewerpy.Const_std_vector_PythonViewer_UiEntry) -> None
        """
    def __iter__(self):
        """
        __iter__(self: meshlib.mrviewerpy.Const_std_vector_PythonViewer_UiEntry) -> Iterator[meshlib.mrviewerpy.ConstUiEntry]
        """
    def __len__(self):
        """
        __len__(self: meshlib.mrviewerpy.Const_std_vector_PythonViewer_UiEntry) -> int
        """
    def data_pointer(self):
        """
        data_pointer(self: meshlib.mrviewerpy.Const_std_vector_PythonViewer_UiEntry) -> int
        
        Returns the pointer to the contiguous vector contents, as an integer.
        """
    def empty(self):
        """
        empty(self: meshlib.mrviewerpy.Const_std_vector_PythonViewer_UiEntry) -> bool
        """
    def size(self):
        """
        size(self: meshlib.mrviewerpy.Const_std_vector_PythonViewer_UiEntry) -> int
        """
class std_vector_PythonViewer_UiEntry(Const_std_vector_PythonViewer_UiEntry):
    __slots__: typing.ClassVar[tuple] = tuple()
    def __delitem__(self, i):
        """
        __delitem__(*args, **kwargs)
        Overloaded function.
        
        1. __delitem__(self: meshlib.mrviewerpy.std_vector_PythonViewer_UiEntry, arg0: int) -> None
        
        Delete the list elements at index ``i``
        
        2. __delitem__(self: meshlib.mrviewerpy.std_vector_PythonViewer_UiEntry, arg0: slice) -> None
        
        Delete list elements using a slice object
        """
    def __getitem__(self, i):
        """
        __getitem__(*args, **kwargs)
        Overloaded function.
        
        1. __getitem__(self: meshlib.mrviewerpy.std_vector_PythonViewer_UiEntry, s: slice) -> meshlib.mrviewerpy.std_vector_PythonViewer_UiEntry
        
        Retrieve list elements using a slice object
        
        2. __getitem__(self: meshlib.mrviewerpy.std_vector_PythonViewer_UiEntry, arg0: int) -> meshlib.mrviewerpy.UiEntry
        """
    def __init__(self, *args):
        """
        __init__(*args, **kwargs)
        Overloaded function.
        
        1. __init__(self: meshlib.mrviewerpy.std_vector_PythonViewer_UiEntry) -> None
        
        2. __init__(self: meshlib.mrviewerpy.std_vector_PythonViewer_UiEntry, arg0: Iterable) -> None
        
        3. __init__(self: meshlib.mrviewerpy.std_vector_PythonViewer_UiEntry, arg0: meshlib.mrviewerpy.Const_std_vector_PythonViewer_UiEntry) -> None
        """
    def __iter__(self):
        """
        __iter__(self: meshlib.mrviewerpy.std_vector_PythonViewer_UiEntry) -> Iterator[meshlib.mrviewerpy.UiEntry]
        """
    def __setitem__(self, i, v):
        """
        __setitem__(*args, **kwargs)
        Overloaded function.
        
        1. __setitem__(self: meshlib.mrviewerpy.std_vector_PythonViewer_UiEntry, arg0: int, arg1: meshlib.mrviewerpy.ConstUiEntry) -> None
        
        2. __setitem__(self: meshlib.mrviewerpy.std_vector_PythonViewer_UiEntry, arg0: slice, arg1: meshlib.mrviewerpy.Const_std_vector_PythonViewer_UiEntry) -> None
        
        Assign list elements using a slice object
        """
    def append(self, x):
        """
        append(self: meshlib.mrviewerpy.std_vector_PythonViewer_UiEntry, x: meshlib.mrviewerpy.ConstUiEntry) -> None
        
        Add an item to the end of the list
        """
    def clear(self):
        """
        clear(self: meshlib.mrviewerpy.std_vector_PythonViewer_UiEntry) -> None
        
        Clear the contents
        """
    def extend(self, L):
        """
        extend(*args, **kwargs)
        Overloaded function.
        
        1. extend(self: meshlib.mrviewerpy.std_vector_PythonViewer_UiEntry, L: meshlib.mrviewerpy.Const_std_vector_PythonViewer_UiEntry) -> None
        
        Extend the list by appending all the items in the given list
        
        2. extend(self: meshlib.mrviewerpy.std_vector_PythonViewer_UiEntry, L: Iterable) -> None
        
        Extend the list by appending all the items in the given list
        """
    def insert(self, i, x):
        """
        insert(self: meshlib.mrviewerpy.std_vector_PythonViewer_UiEntry, i: int, x: meshlib.mrviewerpy.ConstUiEntry) -> None
        
        Insert an item at a given position.
        """
    def pop(self, i = -1):
        """
        pop(*args, **kwargs)
        Overloaded function.
        
        1. pop(self: meshlib.mrviewerpy.std_vector_PythonViewer_UiEntry) -> meshlib.mrviewerpy.UiEntry
        
        Remove and return the last item
        
        2. pop(self: meshlib.mrviewerpy.std_vector_PythonViewer_UiEntry, i: int) -> meshlib.mrviewerpy.UiEntry
        
        Remove and return the item at index ``i``
        """
    def resize(self, n, *v):
        """
        resize(*args, **kwargs)
        Overloaded function.
        
        1. resize(self: meshlib.mrviewerpy.std_vector_PythonViewer_UiEntry, arg0: int) -> None
        
        2. resize(self: meshlib.mrviewerpy.std_vector_PythonViewer_UiEntry, arg0: int, arg1: meshlib.mrviewerpy.ConstUiEntry) -> None
        """
class Const_std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry:
    __slots__: typing.ClassVar[tuple] = tuple()
    element_type_byte_size: typing.ClassVar[int] = 96
    def __bool__(self):
        """
        __bool__(self: meshlib.mrviewerpy.Const_std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry) -> bool
        
        Check whether the list is nonempty
        """
    def __getitem__(self, i):
        """
        __getitem__(*args, **kwargs)
        Overloaded function.
        
        1. __getitem__(self: meshlib.mrviewerpy.Const_std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry, s: slice) -> meshlib.mrviewerpy.std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry
        
        Retrieve list elements using a slice object
        
        2. __getitem__(self: meshlib.mrviewerpy.Const_std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry, arg0: int) -> tuple[meshlib.mrmeshpy.std_vector_std_string, meshlib.mrviewerpy.UiEntry]
        """
    def __init__(self, *args, **kwargs):
        """
        __init__(*args, **kwargs)
        Overloaded function.
        
        1. __init__(self: meshlib.mrviewerpy.Const_std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry) -> None
        
        2. __init__(self: meshlib.mrviewerpy.Const_std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry, arg0: Iterable) -> None
        
        3. __init__(self: meshlib.mrviewerpy.Const_std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry, arg0: meshlib.mrviewerpy.Const_std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry) -> None
        """
    def __iter__(self):
        """
        __iter__(self: meshlib.mrviewerpy.Const_std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry) -> Iterator[tuple[meshlib.mrmeshpy.std_vector_std_string, meshlib.mrviewerpy.UiEntry]]
        """
    def __len__(self):
        """
        __len__(self: meshlib.mrviewerpy.Const_std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry) -> int
        """
    def data_pointer(self):
        """
        data_pointer(self: meshlib.mrviewerpy.Const_std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry) -> int
        
        Returns the pointer to the contiguous vector contents, as an integer.
        """
    def empty(self):
        """
        empty(self: meshlib.mrviewerpy.Const_std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry) -> bool
        """
    def size(self):
        """
        size(self: meshlib.mrviewerpy.Const_std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry) -> int
        """
class std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry(Const_std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry):
    __slots__: typing.ClassVar[tuple] = tuple()
    def __delitem__(self, i):
        """
        __delitem__(*args, **kwargs)
        Overloaded function.
        
        1. __delitem__(self: meshlib.mrviewerpy.std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry, arg0: int) -> None
        
        Delete the list elements at index ``i``
        
        2. __delitem__(self: meshlib.mrviewerpy.std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry, arg0: slice) -> None
        
        Delete list elements using a slice object
        """
    def __init__(self, *args):
        """
        __init__(*args, **kwargs)
        Overloaded function.
        
        1. __init__(self: meshlib.mrviewerpy.std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry) -> None
        
        2. __init__(self: meshlib.mrviewerpy.std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry, arg0: Iterable) -> None
        
        3. __init__(self: meshlib.mrviewerpy.std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry, arg0: meshlib.mrviewerpy.Const_std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry) -> None
        """
    def __setitem__(self, i, v):
        """
        __setitem__(*args, **kwargs)
        Overloaded function.
        
        1. __setitem__(self: meshlib.mrviewerpy.std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry, arg0: int, arg1: tuple[meshlib.mrmeshpy.Const_std_vector_std_string, meshlib.mrviewerpy.ConstUiEntry]) -> None
        
        2. __setitem__(self: meshlib.mrviewerpy.std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry, arg0: slice, arg1: meshlib.mrviewerpy.Const_std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry) -> None
        
        Assign list elements using a slice object
        """
    def append(self, x):
        """
        append(self: meshlib.mrviewerpy.std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry, x: tuple[meshlib.mrmeshpy.Const_std_vector_std_string, meshlib.mrviewerpy.ConstUiEntry]) -> None
        
        Add an item to the end of the list
        """
    def clear(self):
        """
        clear(self: meshlib.mrviewerpy.std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry) -> None
        
        Clear the contents
        """
    def extend(self, L):
        """
        extend(*args, **kwargs)
        Overloaded function.
        
        1. extend(self: meshlib.mrviewerpy.std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry, L: meshlib.mrviewerpy.Const_std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry) -> None
        
        Extend the list by appending all the items in the given list
        
        2. extend(self: meshlib.mrviewerpy.std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry, L: Iterable) -> None
        
        Extend the list by appending all the items in the given list
        """
    def insert(self, i, x):
        """
        insert(self: meshlib.mrviewerpy.std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry, i: int, x: tuple[meshlib.mrmeshpy.Const_std_vector_std_string, meshlib.mrviewerpy.ConstUiEntry]) -> None
        
        Insert an item at a given position.
        """
    def pop(self, i = -1):
        """
        pop(*args, **kwargs)
        Overloaded function.
        
        1. pop(self: meshlib.mrviewerpy.std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry) -> tuple[meshlib.mrmeshpy.std_vector_std_string, meshlib.mrviewerpy.UiEntry]
        
        Remove and return the last item
        
        2. pop(self: meshlib.mrviewerpy.std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry, i: int) -> tuple[meshlib.mrmeshpy.std_vector_std_string, meshlib.mrviewerpy.UiEntry]
        
        Remove and return the item at index ``i``
        """
    def resize(self, n, *v):
        """
        resize(*args, **kwargs)
        Overloaded function.
        
        1. resize(self: meshlib.mrviewerpy.std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry, arg0: int) -> None
        
        2. resize(self: meshlib.mrviewerpy.std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry, arg0: int, arg1: tuple[meshlib.mrmeshpy.Const_std_vector_std_string, meshlib.mrviewerpy.ConstUiEntry]) -> None
        """
class double_output:
    """
    A helper class containing a list of scalars. This is used for functions with scalar output parameters.
    NOTE: If a function outputs an array, you must manually resize this to the correct size or risk undefined behavior.
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    values = ...
    def __init__(self, *args):
        """
        __init__(*args, **kwargs)
        Overloaded function.
        
        1. __init__(self: meshlib.mrviewerpy.double_output) -> None
        
        2. __init__(self: meshlib.mrviewerpy.double_output, arg0: int) -> None
        
        3. __init__(self: meshlib.mrviewerpy.double_output, arg0: int, arg1: float) -> None
        """
    def __repr__(self):
        """
        __repr__(self: meshlib.mrviewerpy.double_output) -> str
        """
    @property
    def value(self):
        """
        If the list contains exactly one value, returns it. Otherwise throws.
        """
    @value.setter
    def value(self, v):
        ...
class float_output:
    """
    A helper class containing a list of scalars. This is used for functions with scalar output parameters.
    NOTE: If a function outputs an array, you must manually resize this to the correct size or risk undefined behavior.
    """
    __slots__: typing.ClassVar[tuple] = tuple()
    values = ...
    def __init__(self, *args):
        """
        __init__(*args, **kwargs)
        Overloaded function.
        
        1. __init__(self: meshlib.mrviewerpy.float_output) -> None
        
        2. __init__(self: meshlib.mrviewerpy.float_output, arg0: int) -> None
        
        3. __init__(self: meshlib.mrviewerpy.float_output, arg0: int, arg1: float) -> None
        """
    def __repr__(self):
        """
        __repr__(self: meshlib.mrviewerpy.float_output) -> str
        """
    @property
    def value(self):
        """
        If the list contains exactly one value, returns it. Otherwise throws.
        """
    @value.setter
    def value(self, v):
        ...
def _optionalList(field):
    ...
def _uiEntryRepr(e):
    ...
def _uiListAllEntries(rootPath: meshlib.mrmeshpy.Const_std_vector_std_string) -> std_vector_std_pair_std_vector_std_string_PythonViewer_UiEntry:
    """
    Flat depth-first list of every UI entry in the subtree rooted at `rootPath`.
    Pass an empty list for the whole tree.
    Each element is a `(path, UiEntry)` tuple where `path[-1] == entry.name`.
    """
def _uiListEntries(path: meshlib.mrmeshpy.Const_std_vector_std_string) -> std_vector_PythonViewer_UiEntry:
    """
    List existing UI entries at the specified path.
    Pass an empty list to see top-level groups.
    Add group name to the end of the vector to see its contents.
    When you find the button you need, pass it to `uiPressButton()`.
    """
def addDistanceMapToScene(distancemap: meshlib.mrmeshpy.ConstDistanceMap, name: str, dmap_to_local_xf: meshlib.mrmeshpy.ConstAffineXf3f) -> None:
    """
    Add given distance map to scene tree.
    """
def addLinesToScene(lines: meshlib.mrmeshpy.ConstPolyline3, name: str) -> None:
    """
    Add given lines to scene tree.
    """
def addMeshToScene(mesh: meshlib.mrmeshpy.ConstMesh, name: str) -> None:
    """
    Add given mesh to scene tree.
    """
def addPointCloudToScene(points: meshlib.mrmeshpy.ConstPointCloud, name: str) -> None:
    """
    Add given point cloud to scene tree.
    """
def addVoxelsToScene(voxels: meshlib.mrmeshpy.ConstVdbVolume, name: str) -> None:
    """
    Add given voxels to scene tree.
    """
def clearScene() -> None:
    """
    remove all objects from scene tree
    """
def getPrimaryCtrlKeyMod() -> KeyMod:
    """
    Returns the main control modifier of this platform: `KeyMod.Super` (Cmd) on macOS, `KeyMod.Ctrl` otherwise.
    """
def getSelectedDistanceMaps() -> meshlib.mrmeshpy.std_vector_DistanceMap:
    """
    Get copies of all selected voxel grids in the scene.
    """
def getSelectedMeshEdges() -> meshlib.mrmeshpy.std_vector_TypedBitSet_Id_UndirectedEdgeTag:
    """
    Get selected edge bitsets of the selected mesh objects.
    """
def getSelectedMeshFaces() -> meshlib.mrmeshpy.std_vector_TypedBitSet_Id_FaceTag:
    """
    Get selected face bitsets of the selected mesh objects.
    """
def getSelectedMeshes() -> meshlib.mrmeshpy.std_vector_Mesh:
    """
    Get copies of all selected meshes in the scene.
    """
def getSelectedObjects() -> meshlib.mrmeshpy.std_vector_std_shared_ptr_Object:
    ...
def getSelectedPointCloudPoints() -> meshlib.mrmeshpy.std_vector_TypedBitSet_Id_VertTag:
    """
    Get selected point bitsets of the selected point cloud objects.
    """
def getSelectedPointClouds() -> meshlib.mrmeshpy.std_vector_PointCloud:
    """
    Get copies of all selected point clouds in the scene.
    """
def getSelectedPolylines() -> meshlib.mrmeshpy.std_vector_Polyline_Vector3_float:
    """
    Get copies of all selected polylines in the scene.
    """
def getSelectedVoxels() -> meshlib.mrmeshpy.std_vector_VoxelsVolumeMinMax_FloatGrid:
    """
    Get copies of all selected voxel grids in the scene.
    """
def launch(params: ConstViewerLaunchParams = ..., setup: ConstViewerSetup = ...) -> None:
    """
    Starts the viewer with the given params and setup, and returns once it is up and accepts calls.
    On Windows and Linux the window opens here, and the script keeps running alongside it.
    On macOS the viewer runs on the calling thread, which must be the main one: the window opens in showViewer(), or at the interactive prompt, where it stays live while the interpreter waits for input, in input() too.
    Raises RuntimeError if the viewer could not start (no display, or already launched once in this process).
    """
def modifySelectedMesh(mesh: meshlib.mrmeshpy.ConstMesh) -> None:
    """
    Assign a new mesh to the selected mesh object. Exactly one object must be selected.
    """
def runFromGUIThread(lambda_: meshlib.mrmeshpy.Const_func_void) -> None:
    """
    Executes given function from GUI thread, and returns after it is done
    """
def selectByName(objectName: str) -> None:
    """
    select objects in scene tree with given name, unselect others
    """
def selectByType(typeName: str) -> None:
    """
    string typeName: {"Meshes", "Points", "Voxels"}
    objects in scene tree with given type, unselect others
    """
def setSelectedMeshEdges(bitsets: meshlib.mrmeshpy.Const_std_vector_TypedBitSet_Id_UndirectedEdgeTag) -> None:
    """
    Set selected edge bitsets of the selected mesh objects.
    """
def setSelectedMeshFaces(bitsets: meshlib.mrmeshpy.Const_std_vector_TypedBitSet_Id_FaceTag) -> None:
    """
    Set selected face bitsets of the selected mesh objects.
    """
def setSelectedPointCloudPoints(bitsets: meshlib.mrmeshpy.Const_std_vector_TypedBitSet_Id_VertTag) -> None:
    """
    Set selected point bitsets of the selected point cloud objects.
    """
def showViewer() -> None:
    """
    Keeps the window open until the user closes it or shutdown() is called from another thread.
    On macOS the window opens here, so this call is required there; make it from the main thread.
    After it returns the viewer is closed for good, and further viewer calls raise RuntimeError.
    """
def uiListAllEntries(rootPath):
    """
    uiListAllEntries(rootPath: list[str]) -> list[tuple[list[str], meshlib.mrviewerpy.UiEntry]]
    
    Flat depth-first list of every UI entry in the subtree rooted at `rootPath`.
    Pass an empty list for the whole tree.
    Each element is a `(path, UiEntry)` tuple where `path[-1] == entry.name`.
    """
def uiListEntries(path):
    """
    uiListEntries(path: list[str]) -> list[meshlib.mrviewerpy.UiEntry]
    
    List existing UI entries at the specified path.
    Pass an empty list to see top-level groups.
    Add group name to the end of the vector to see its contents.
    When you find the button you need, pass it to `uiPressButton()`.
    """
def uiPressButton(path: meshlib.mrmeshpy.Const_std_vector_std_string) -> None:
    """
    Simulate a button click. Use `uiListEntries()` to find button names.
    """
def uiReadValueInt(path: meshlib.mrmeshpy.Const_std_vector_std_string) -> UiValueInt:
    """
    Read a value from a drag/slider widget. This function is for signed integers.
    """
def uiReadValueReal(path: meshlib.mrmeshpy.Const_std_vector_std_string) -> UiValueReal:
    """
    Read a value from a drag/slider widget. This function is for real numbers.
    """
def uiReadValueString(path: meshlib.mrmeshpy.Const_std_vector_std_string) -> UiValueString:
    """
    Read a value from a drag/slider widget. This function is for strings.
    """
def uiReadValueUint(path: meshlib.mrmeshpy.Const_std_vector_std_string) -> UiValueUint:
    """
    Read a value from a drag/slider widget. This function is for unsigned integers.
    """
@typing.overload
def uiWriteValue(path: meshlib.mrmeshpy.Const_std_vector_std_string, value: int) -> None:
    """
    Write a value to a drag/slider widget. This overload is for signed integers.
    """
@typing.overload
def uiWriteValue(path: meshlib.mrmeshpy.Const_std_vector_std_string, value: int) -> None:
    """
    Write a value to a drag/slider widget. This overload is for unsigned integers.
    """
@typing.overload
def uiWriteValue(path: meshlib.mrmeshpy.Const_std_vector_std_string, value: float) -> None:
    """
    Write a value to a drag/slider widget. This overload is for real numbers.
    """
@typing.overload
def uiWriteValue(path: meshlib.mrmeshpy.Const_std_vector_std_string, value: str) -> None:
    """
    Write a value to a drag/slider widget. This overload is for strings.
    """
def unselectAll() -> None:
    """
    unselect all objects in scene tree
    """
__mrbind_cpp_api__: typing.Any
